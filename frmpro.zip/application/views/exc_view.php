<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Example View</title>
</head>
<body>
    <h1>INI ADALAH CONTOH VIEW PADA CODEIGNITER</h1>
    <hr>
    <h3>Learning Session Codeigniter</h3>
</body>
</html>